package com.tuple.examples

class Student {
  def main(args: Array[String]): Unit = {
    
  }
}