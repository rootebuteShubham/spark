object myWorksheet {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(64); 
  println("Welcome to the Scala worksheet");$skip(22); 
  
  println("Hello");$skip(9); val res$0 = 
  
  1+1;System.out.println("""res0: Int(2) = """ + $show(res$0));$skip(30); 
  
  println("Hi Edureka!!!")}
}
